// 为兼容多端，通过公共js引用判别程序运行环境
var navigator = {
	'userAgent' : 'wx_sapp',
}
module.exports = {
	navigator : navigator
};