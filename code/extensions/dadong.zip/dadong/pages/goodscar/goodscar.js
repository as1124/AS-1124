var QQMapWX = require('../../common/qqmap-wx-jssdk.js');
const APP_REF = getApp();

Page({
    data: {},
    onLoad: function(options) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});