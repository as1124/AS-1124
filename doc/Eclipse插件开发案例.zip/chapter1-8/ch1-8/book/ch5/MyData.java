package book.ch5;

public class MyData {
	public int ratio = 10;
}
