package com.plugindev.addressbook.models;

public interface AddressManagerListener {
	   public void addressesChanged(AddressManagerEvent event);
}
